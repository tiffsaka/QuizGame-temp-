//
//  JournalListViewController.swift
//  Journal
//
//  Created by Tiffany Sakaguchi on 4/20/21.
//

import UIKit

class JournalListViewController: UIViewController {
    
    
    @IBOutlet weak var journalTitleTextField: UITextField!
    @IBOutlet weak var journalListTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        journalListTableView.delegate = self
        journalListTableView.dataSource = self
        JournalController.sharedInstance.loadFromPersistenceStore()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        journalListTableView.reloadData()
    }
    
    @IBAction func createNewJournalButtonTapped(_ sender: Any) {
        guard let title = journalTitleTextField.text, !title.isEmpty else { return }
        JournalController.sharedInstance.createJournalWith(title: title)
        journalListTableView.reloadData()
        journalTitleTextField.text = ""
    }
    

    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        //IIDOO
        if segue.identifier == "toEntryList" {
            
            guard let indexPath = journalListTableView.indexPathForSelectedRow,
                  let destination = segue.destination as? EntryListTableViewController else { return }
            
            let journalToSend = JournalController.sharedInstance.journals[indexPath.row]
            destination.journal = journalToSend
        }
    }

} //End of class


//MARK: - Extensions

extension JournalListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        JournalController.sharedInstance.journals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = journalListTableView.dequeueReusableCell(withIdentifier: "journalCell", for: indexPath)
        let journal = JournalController.sharedInstance.journals[indexPath.row]
        cell.textLabel?.text = journal.title
        
        if journal.entries.count == 1 {
            cell.detailTextLabel?.text = "1 Entry"
        } else {
            cell.detailTextLabel?.text = "\(journal.entries.count) Entries"
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let journalToDelete = JournalController.sharedInstance.journals[indexPath.row]
            JournalController.sharedInstance.delete(journal: journalToDelete)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }
    
} //End of extension
