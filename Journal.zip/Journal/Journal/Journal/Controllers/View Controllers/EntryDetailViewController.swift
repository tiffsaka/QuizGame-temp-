//
//  EntryDetailViewController.swift
//  Journal
//
//  Created by Tiffany Sakaguchi on 4/19/21.
//

import UIKit

class EntryDetailViewController: UIViewController {
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var bodyTextField: UITextField!
    
    var entry: Entry?
    var journal: Journal?
    
   
    //MARK: - Lifecyle
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
    }
    
    @IBAction func clearButtonPressed(_ sender: Any) {
        titleTextField.text = ""
        bodyTextField.text = ""
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        
        guard let title = titleTextField.text, !title.isEmpty,
              let body = bodyTextField.text, !body.isEmpty,
              let journal = journal else { return }
        if let entry = entry {
            EntryController.update(entry: entry, title: title, body: body)
        } else {
            EntryController.createEntry(withTitle: title, body: body, journal: journal)
        }
        navigationController?.popViewController(animated: true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
    }

    
    func updateViews() {
        guard let entry = entry else { return }
        titleTextField.text = entry.title
        bodyTextField.text = entry.body
    }
    
} //End of class
