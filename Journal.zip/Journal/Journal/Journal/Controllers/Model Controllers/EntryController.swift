//
//  EntryController.swift
//  Journal
//
//  Created by Tiffany Sakaguchi on 4/19/21.
//

import Foundation

class EntryController {
    
    static func createEntry(withTitle title: String, body: String, journal: Journal) {
        let newEntry = Entry(title: title, body: body)
        JournalController.sharedInstance.addEntryTo(journal: journal, entry: newEntry)
        
    }
    
    static func deleteEntry(entry: Entry, journal: Journal) {
        JournalController.sharedInstance.removeEntryFrom(journal: journal, entry: entry)
    }
    
    
    static func update(entry: Entry, title: String, body: String) {
        entry.title = title
        entry.body = body
        JournalController.sharedInstance.saveToPersistenceStore()
    }
    
}//End of class








