//
//  Entry.swift
//  Journal
//
//  Created by Tiffany Sakaguchi on 4/19/21.
//

import Foundation


class Entry: Codable {
    
    var title: String
    var body: String
    let timestamp: Date
    let uuid: String
    
    init(title: String, body: String, timestamp: Date = Date(), uuid: String = UUID().uuidString) {
        self.title = title
        self.body = body
        self.timestamp = timestamp
        self.uuid = uuid
    }
    
} //End of class


extension Entry: Equatable {
    static func == (lhs: Entry, rhs: Entry) -> Bool {
        return lhs.uuid == rhs.uuid
    }
    
} // End of extension






